Martian Attack - JagCode 2007
-----------------------------

It is Martian year 3257. Frustrated with the repeated eclipses of Leader's
favourite heavenly body, Venus, you have been dispatched to remove the
blue obstruction.

Guiding your Orbital Destruction Sphere, you set out on what should be
a routine cleanup mission, only to encounted unexepcted resistance from
an unknown source! Failure is not an option! Fight through the 
opposition and clear the path for Leader's telescopes!

Load the game using BJL on the .COF file. MA also seems to run under
Project Tempest using the BIN file (load and start address '4000'),
but the starfield does not appear.

You may move your crosshairs, represented by an 'x', using the d-pad.
To begin the game, press 'A'.

As the game begins, your score will be displayed along the bottom, as
your ODS moves up into place. As you continue through space, alien
ships will begin to attack you. Line up the crosshairs and press
A to fire - it will take several shots to destroy it, but beware -
reinforcements are not far behind!

The alien ships will fire red energy spheres at you. While inferior
to our own technology, they still contain sufficient energy to
damage your deflector shield. Line up your crosshairs and press A
to destroy these spheres before they hit your shield.

One the target planet is in range, your computer will notify you,
and you main begin your assault. Line up your crosshairs over the
planet and press A to fire. Be prepared for significant resistance
at this point!

Should the unthinkable happen, and your fighter be destroyed, the
ODS will return on autopilot to Mars, and another brave fighter
will be given the opportunity to complete the mission. You will
be forgotten.

All kidding aside, the primary point here is to score points. With
that in mind:

Energy sphere     10 pts
Damage enemy      20 pts
Destroy enemy    100 pts additional
Destroy planet	1000 pts

NOTE: I don't want anyone to be disappointed, so let me just
say up front that there is no flashy explosion when the planet
is destroyed! I ran out of time, and I'd rather make excuses
now than have anyone disappointed - because trust me, it's not
an easy task. Nor is it impossible!

